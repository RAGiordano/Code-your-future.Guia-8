/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entities;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Usuario
 */
public class Game {
    private List<Player> players;
    private WaterGun waterGun;
    

    public Game() {
    }

    public Game(List<Player> players, WaterGun waterGun) {
        this.players = players;
        this.waterGun = waterGun;
    }
    
    
    
    public void fillGame(ArrayList<Player> players, WaterGun waterGun){
        this.players = players;
        this.waterGun = waterGun;
    }
    
    public byte round(){
        
    }
    
}
