/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Services;

import Entities.Player;
import Entities.WaterGun;

/**
 *
 * @author Usuario
 */
public class PlayerService {
    private WaterGunService waterGunService = new WaterGunService();
    
    public PlayerService() {
    }
    
    public boolean shot (WaterGun waterGun, Player player){
        
        if (waterGunService.shot(waterGun)){
            System.out.println("¡Mojado!");
            player.setWet(true);
            return true;
        } else {
            waterGunService.nextShot(waterGun);
            return false;
        }
    }
}
