package com.rag.library;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EggLibraryApplicationTests {

	@Test
	void contextLoads() {
	}

}
