package com.rag.library;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EggLibraryApplication {

	public static void main(String[] args) {
		SpringApplication.run(EggLibraryApplication.class, args);
	}

}
