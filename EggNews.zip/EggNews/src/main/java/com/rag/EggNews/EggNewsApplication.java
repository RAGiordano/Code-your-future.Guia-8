package com.rag.EggNews;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EggNewsApplication {

	public static void main(String[] args) {
		SpringApplication.run(EggNewsApplication.class, args);
	}

}
